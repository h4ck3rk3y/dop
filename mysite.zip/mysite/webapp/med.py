import nltk
medicine = nltk.defaultdict(str)
medicine['fever'] = 'paracetamol'
medicine['eyepain'] = 'get to nearest hospital'
medicine['musclepain'] = 'get to nearest hospital'
medicine['gumbleed'] = 'decrease in platelet count get to nearest hospital'
medicine['rash'] = 'internal bleeding get to nearest hospital'
medicine['vomit'] = 'take perinorm'
medicine['bleed'] = 'get to nearest hospital'
#medicine['pain'] = 'get to nearest hospital'

