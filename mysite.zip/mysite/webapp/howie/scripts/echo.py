#!/usr/bin/python
import sys
for item in sys.argv[1:]:
	print item,