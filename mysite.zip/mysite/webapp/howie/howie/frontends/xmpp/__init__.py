# $Id: __init__.py,v 1.3 2004/10/12 17:32:01 cort Exp $

import simplexml,protocol,debug,auth,transports,roster,dispatcher,features,filetransfer
from client import *
from protocol import *

__version__ = "0.1.1"
