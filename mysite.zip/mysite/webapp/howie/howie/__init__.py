__all__ = ["configFile", "core"]
